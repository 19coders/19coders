
module.exports = {
  // App name.
  appName: 'Radar Payments',

  // Server port.
  port: 3000,

  // Secret for cookie sessions.
  secret: '8CCzYysjF7MYA0irdK',

  // Configuration for Stripe.
  // API Keys: https://dashboard.stripe.com/account/apikeys
  // Connect Settings: https://dashboard.stripe.com/account/applications/settings
  stripe: {
    secretKey: 'sk_live_6IFgxg8CCzYysjF7MYA0irdK',
    publishableKey: 'pk_live_m4iOOg8R5wEUonye6Ipb6TBU',
    clientId: 'ca_BcpqmIFRc4Ww0zN49sycchHGjXaOfF40',
    authorizeUri: 'https://connect.stripe.com/express/oauth/authorize',
    tokenUri: 'https://connect.stripe.com/express/oauth/token'
  },

  // Configuration for MongoDB.
  mongo: {
    uri: 'mongodb://localhost:27017/db'
  },

  // Configuration for Google Cloud (only useful if you want to deploy to GCP).
  gcloud: {
    projectId: 'YOUR_PROJECT_ID'
  }
};
